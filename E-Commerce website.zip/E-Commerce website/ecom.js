
  // Handle form submission
  $('#registration-form').submit(function (event) {
    event.preventDefault(); // Prevent form submission

    // Perform form validation here if needed

    // Show success page and hide registration form
    $('#success-page').show();
    $('#registration-form').hide();
  });
 // Handle delete product form submission
 $('#delete-product-form').submit(function (event) {
    event.preventDefault(); // Prevent form submission

    var productID = $('#delete-product-id').val();

    $('#delete-product-id').val('');
  });
  // Handle edit product form submission
  $('#edit-product-form').submit(function (event) {
    event.preventDefault(); // Prevent form submission

    // Get the edited values from the form inputs
    var editedProductName = $('#edit-product-name').val();
    var editedProductDescription = $('#edit-product-description').val();
    var editedProductPrice = $('#edit-product-price').val();

    // Perform form validation here if needed

    // Update the product data with the edited values (e.g., send changes to a server, update in a database)

    // Optionally, display a success message or redirect to a success page

    // Clear the form inputs
    $('#edit-product-name').val('');
    $('#edit-product-description').val('');
    $('#edit-product-price').val('');
  });
   // Handle product form submission
   $('#product-form').submit(function (event) {
    event.preventDefault(); // Prevent form submission

    // Get the values from the form inputs
    var productName = $('#product-name').val();
    var productDescription = $('#product-description').val();
    var productPrice = $('#product-price').val();

    // Perform form validation here if needed

    // Process the form data (e.g., send it to a server, store it in a database)

    // Optionally, display a success message or redirect to a success page

    // Clear the form inputs
    $('#product-name').val('');
    $('#product-description').val('');
    $('#product-price').val('');
  });